package vn.codegym.inotes.web;

import vn.codegym.inotes.model.Note;
import vn.codegym.inotes.service.NoteManagement;
import vn.codegym.inotes.strategy.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

@WebServlet("/notes/*")
public class NotesServlet extends HttpServlet {
    private NoteManagement management;
    @Override public void init(){management=new NoteManagement(strategy(System.getenv().getOrDefault("INOTES_STORAGE","file")));}
    private NoteStrategy strategy(String name){return "db".equalsIgnoreCase(name)?new NoteDBStrategy():new NoteFileStrategy();}
    @Override protected void doGet(HttpServletRequest req,HttpServletResponse resp)throws ServletException,IOException{
        try{
            String path=req.getPathInfo()==null?"/":req.getPathInfo();
            if("/new".equals(path)||"/edit".equals(path)){boolean edit="/edit".equals(path);Note n=edit?management.searchNotes("").stream().filter(x->x.getId()==Integer.parseInt(req.getParameter("id"))).findFirst().orElse(null):new Note();if(n==null){resp.sendError(404);return;}req.setAttribute("note",n);req.setAttribute("editing",edit);req.setAttribute("types",management.getStrategy().findTypes());req.getRequestDispatcher("/WEB-INF/views/form.jsp").forward(req,resp);return;}
            if("/storage".equals(path)){String kind="db".equalsIgnoreCase(req.getParameter("type"))?"db":"file";management.setStrategy(strategy(kind));resp.sendRedirect(req.getContextPath()+"/notes");return;}
            req.setAttribute("notes",management.searchNotes(req.getParameter("q")));req.setAttribute("types",management.getStrategy().findTypes());req.setAttribute("storage",management.getStrategy() instanceof NoteDBStrategy?"db":"file");req.getRequestDispatcher("/WEB-INF/views/notes.jsp").forward(req,resp);
        }catch(Exception e){throw new ServletException("Không thể tải ghi chú",e);}
    }
    @Override protected void doPost(HttpServletRequest req,HttpServletResponse resp)throws ServletException,IOException{
        req.setCharacterEncoding("UTF-8");try{String action=req.getParameter("action");if("delete".equals(action)){management.deleteNote(Integer.parseInt(req.getParameter("id")));}else{Note n=new Note();String id=req.getParameter("id");if(id!=null&&!id.isBlank())n.setId(Integer.parseInt(id));n.setTitle(req.getParameter("title"));n.setContent(req.getParameter("content"));n.setTypeId(Integer.parseInt(req.getParameter("typeId")));management.save(n);}resp.sendRedirect(req.getContextPath()+"/notes?saved=1");}catch(IllegalArgumentException e){resp.sendError(400,e.getMessage());}catch(Exception e){throw new ServletException("Không thể lưu ghi chú",e);}
    }
}
