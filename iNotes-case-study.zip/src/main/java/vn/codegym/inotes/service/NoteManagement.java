package vn.codegym.inotes.service;

import vn.codegym.inotes.model.Note;
import vn.codegym.inotes.strategy.NoteStrategy;
import java.util.List;

public class NoteManagement {
    private NoteStrategy strategy;
    public NoteManagement(NoteStrategy strategy){this.strategy=strategy;}
    public void setStrategy(NoteStrategy strategy){if(strategy==null)throw new IllegalArgumentException("Storage strategy is required");this.strategy=strategy;}
    public NoteStrategy getStrategy(){return strategy;}
    public List<Note> searchNotes(String keyword) throws Exception{return keyword==null||keyword.trim().isEmpty()?strategy.findAll():strategy.search(keyword);}
    public void addNote(String title,String content,int typeId) throws Exception{Note n=new Note(0,title,content,typeId);save(n);}
    public void save(Note n) throws Exception{if(n.getTitle()==null||n.getTitle().trim().isEmpty())throw new IllegalArgumentException("Tiêu đề không được để trống.");if(n.getTitle().trim().length()>255)throw new IllegalArgumentException("Tiêu đề tối đa 255 ký tự.");if(n.getTypeId()<1||n.getTypeId()>3)throw new IllegalArgumentException("Phân loại không hợp lệ.");n.setTitle(n.getTitle().trim());strategy.save(n);}
    public void deleteNote(int id) throws Exception{if(id<=0)throw new IllegalArgumentException("ID không hợp lệ.");strategy.delete(id);}
}
