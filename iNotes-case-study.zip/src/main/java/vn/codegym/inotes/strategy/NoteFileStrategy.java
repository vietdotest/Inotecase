package vn.codegym.inotes.strategy;

import vn.codegym.inotes.model.Note;
import vn.codegym.inotes.model.NoteType;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

public class NoteFileStrategy implements NoteStrategy {
    private final Path file;
    public NoteFileStrategy(){this(Paths.get(System.getenv().getOrDefault("INOTES_FILE","data/notes.txt")));}
    public NoteFileStrategy(Path file){this.file=file;}
    private List<Note> read() throws IOException {
        List<Note> notes=new ArrayList<>();if(!Files.exists(file))return notes;
        for(String line:Files.readAllLines(file,StandardCharsets.UTF_8)){if(line.trim().isEmpty())continue;List<String> f=decode(line);if(f.size()==4){Note n=new Note(Integer.parseInt(f.get(0)),f.get(1),f.get(2),Integer.parseInt(f.get(3)));n.setTypeName(typeName(n.getTypeId()));notes.add(n);}}
        return notes;
    }
    public synchronized void save(Note note) throws IOException {
        List<Note> notes=read();if(note.getId()<=0)note.setId(notes.stream().mapToInt(Note::getId).max().orElse(0)+1);
        notes.removeIf(n->n.getId()==note.getId());note.setTypeName(typeName(note.getTypeId()));notes.add(note);write(notes);
    }
    public synchronized void delete(int id) throws IOException {List<Note> notes=read();notes.removeIf(n->n.getId()==id);write(notes);}
    public List<Note> findAll() throws IOException {List<Note> n=read();n.sort(Comparator.comparingInt(Note::getId).reversed());return n;}
    public List<Note> search(String keyword) throws IOException {String q=keyword==null?"":keyword.toLowerCase(Locale.ROOT);List<Note> out=new ArrayList<>();for(Note n:findAll())if(n.getTitle().toLowerCase(Locale.ROOT).contains(q)||n.getContent().toLowerCase(Locale.ROOT).contains(q))out.add(n);return out;}
    public List<NoteType> findTypes(){return Arrays.asList(new NoteType(1,"Cá nhân"),new NoteType(2,"Công việc"),new NoteType(3,"Học tập"));}
    private void write(List<Note> notes) throws IOException {Path parent=file.toAbsolutePath().getParent();if(parent!=null)Files.createDirectories(parent);List<String> rows=new ArrayList<>();for(Note n:notes)rows.add(encode(Integer.toString(n.getId()))+"|"+encode(n.getTitle())+"|"+encode(n.getContent())+"|"+n.getTypeId());Files.write(file,rows,StandardCharsets.UTF_8);}
    private static String encode(String s){return s.replace("\\","\\\\").replace("|","\\p").replace("\r","\\r").replace("\n","\\n");}
    private static List<String> decode(String s){List<String> out=new ArrayList<>();StringBuilder b=new StringBuilder();boolean esc=false;for(char c:s.toCharArray()){if(esc){b.append(c=='p'?'|':c=='n'?'\n':c=='r'?'\r':c);esc=false;}else if(c=='\\')esc=true;else if(c=='|'){out.add(b.toString());b.setLength(0);}else b.append(c);}if(esc)b.append('\\');out.add(b.toString());return out;}
    private static String typeName(int id){return id==1?"Cá nhân":id==2?"Công việc":id==3?"Học tập":"Khác";}
}
