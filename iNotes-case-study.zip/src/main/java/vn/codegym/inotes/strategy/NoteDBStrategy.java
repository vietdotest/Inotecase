package vn.codegym.inotes.strategy;

import vn.codegym.inotes.model.Note;
import vn.codegym.inotes.model.NoteType;
import java.sql.*;
import java.util.*;

public class NoteDBStrategy implements NoteStrategy {
    private Connection connection() throws SQLException {
        String url=env("DB_URL","jdbc:mysql://localhost:3306/inotes_db?useSSL=false&serverTimezone=UTC&allowPublicKeyRetrieval=true");
        return DriverManager.getConnection(url,env("DB_USER","root"),env("DB_PASSWORD",""));
    }
    private static String env(String key,String fallback){String v=System.getenv(key);return v==null?fallback:v;}
    public void save(Note n) throws SQLException {
        String sql=n.getId()>0?"UPDATE notes SET title=?,content=?,type_id=? WHERE id=?":"INSERT INTO notes(title,content,type_id) VALUES(?,?,?)";
        try(Connection c=connection();PreparedStatement p=c.prepareStatement(sql)){
            p.setString(1,n.getTitle());p.setString(2,n.getContent());p.setInt(3,n.getTypeId());if(n.getId()>0)p.setInt(4,n.getId());p.executeUpdate();
        }
    }
    public void delete(int id) throws SQLException {try(Connection c=connection();PreparedStatement p=c.prepareStatement("DELETE FROM notes WHERE id=?")){p.setInt(1,id);p.executeUpdate();}}
    public List<Note> findAll() throws SQLException {return query("SELECT n.id,n.title,n.content,n.type_id,t.name type_name FROM notes n JOIN note_type t ON t.id=n.type_id ORDER BY n.id DESC",null);}
    public List<Note> search(String keyword) throws SQLException {return query("SELECT n.id,n.title,n.content,n.type_id,t.name type_name FROM notes n JOIN note_type t ON t.id=n.type_id WHERE n.title LIKE ? OR n.content LIKE ? ORDER BY n.id DESC",keyword);}
    private List<Note> query(String sql,String keyword) throws SQLException {
        List<Note> result=new ArrayList<>();try(Connection c=connection();PreparedStatement p=c.prepareStatement(sql)){
            if(keyword!=null){String q="%"+keyword.trim()+"%";p.setString(1,q);p.setString(2,q);}
            try(ResultSet r=p.executeQuery()){while(r.next()){Note n=new Note(r.getInt("id"),r.getString("title"),r.getString("content"),r.getInt("type_id"));n.setTypeName(r.getString("type_name"));result.add(n);}}
        }return result;
    }
    public List<NoteType> findTypes() throws SQLException {List<NoteType> a=new ArrayList<>();try(Connection c=connection();PreparedStatement p=c.prepareStatement("SELECT id,name FROM note_type ORDER BY id");ResultSet r=p.executeQuery()){while(r.next())a.add(new NoteType(r.getInt(1),r.getString(2)));}return a;}
}
