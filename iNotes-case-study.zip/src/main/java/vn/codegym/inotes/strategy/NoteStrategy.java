package vn.codegym.inotes.strategy;

import vn.codegym.inotes.model.Note;
import vn.codegym.inotes.model.NoteType;
import java.util.List;

public interface NoteStrategy {
    void save(Note note) throws Exception;
    void delete(int id) throws Exception;
    List<Note> findAll() throws Exception;
    List<Note> search(String keyword) throws Exception;
    List<NoteType> findTypes() throws Exception;
}
