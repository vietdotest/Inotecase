package vn.codegym.inotes.model;

public class NoteType {
    private final int id; private final String name;
    public NoteType(int id, String name){this.id=id;this.name=name;}
    public int getId(){return id;} public String getName(){return name;}
}
