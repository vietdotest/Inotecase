package vn.codegym.inotes.model;

public class Note {
    private int id;
    private String title;
    private String content;
    private int typeId;
    private String typeName;

    public Note() {}
    public Note(int id, String title, String content, int typeId) { this.id=id; this.title=title; this.content=content; this.typeId=typeId; }
    public int getId(){return id;} public void setId(int v){id=v;}
    public String getTitle(){return title;} public void setTitle(String v){title=v;}
    public String getContent(){return content;} public void setContent(String v){content=v;}
    public int getTypeId(){return typeId;} public void setTypeId(int v){typeId=v;}
    public String getTypeName(){return typeName;} public void setTypeName(String v){typeName=v;}
}
