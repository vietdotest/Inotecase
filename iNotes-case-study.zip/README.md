# iNotes Case Study

Ứng dụng JSP/Servlet/JDBC quản lý ghi chú, tìm theo tiêu đề hoặc nội dung, CRUD và chuyển đổi kho dữ liệu lúc chạy bằng Strategy Pattern.

## Cấu trúc lưu trữ

- `INOTES_STORAGE=file` (mặc định): lưu `id|title|content|typeId` trong `data/notes.txt`; dấu `|`, dấu gạch chéo và xuống dòng được escape.
- `INOTES_STORAGE=db`: dùng MySQL `inotes_db`; chạy `database/schema.sql` trước.
- Có thể đặt `INOTES_FILE`, `DB_URL`, `DB_USER`, `DB_PASSWORD` qua biến môi trường.

## Chạy

Java 11, Maven và Tomcat 9: `mvn clean package`, sau đó triển khai `target/inotes.war` lên Tomcat. Mở `/inotes/notes`. Môi trường hiện tại chưa có Maven, MySQL hoặc Tomcat nên chưa xác nhận build WAR/chạy tích hợp.
